// mongosh script, run from inside argus-export/ against the target account DB, BEFORE the import:
//   mongosh "$TARGET_MONGO/1788909013?authSource=admin" --quiet argus_preimage.js
// Saves the target's current version of every doc the import (mongo/*.json) or the optional patch
// (patches/*.json) would replace, by _id, to preimage/<collection>.json (canonical Extended JSON).
// The rollback re-imports these after removing the Argus-tagged docs.
const fs = require('fs');
const path = require('path');
fs.mkdirSync('preimage', { recursive: true });
const total = {};
for (const dir of ['mongo', 'patches', 'common']) {
  if (!fs.existsSync(dir)) continue;
  const target = dir === 'common' ? db.getSiblingDB('common') : db;          // common/: docs for the `common` database
  for (const file of fs.readdirSync(dir).filter(f => f.endsWith('.json'))) {
    const coll = dir === 'patches' ? 'api_info' : path.basename(file, '.json');
    const out = path.join('preimage', (dir === 'patches' ? 'patch_' : dir === 'common' ? 'common_' : '') + path.basename(file));
    const ids = fs.readFileSync(path.join(dir, file), 'utf8').split('\n').filter(Boolean).map(l => EJSON.parse(l)._id);
    const lines = [];
    for (let i = 0; i < ids.length; i += 500) {
      // promoteValues: false keeps BSON types (a double 16.0 stays a double), so the rollback restores docs exactly
      target.getCollection(coll).find({ _id: { $in: ids.slice(i, i + 500) } }, {}, { promoteValues: false }).forEach(d => {
        // the patch only changes `violations`: keep just that field, so the rollback merges it back
        lines.push(EJSON.stringify(dir === 'patches' ? { _id: d._id, violations: d.violations || {} } : d, { relaxed: false }));
      });
    }
    fs.writeFileSync(out, lines.join('\n') + (lines.length ? '\n' : ''));
    total[out] = lines.length;
  }
}
printjson(total);
