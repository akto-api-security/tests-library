// mongosh script, run from inside argus-export/ against the target account DB, after the rebase and BEFORE the import:
//   mongosh "$TARGET_MONGO/1788909013?authSource=admin" --quiet argus_metrics_cleanup.js
// The Guardrail Detection Latency chart (POST /api/metrics, metricIdPrefix GUARDRAIL_) plots one point per
// GUARDRAIL_* timestamp but reads only GUARDRAIL_REQUEST_LATENCY / GUARDRAIL_RESPONSE_LATENCY, so the guardrail
// service's other gauges (CPU, memory, cache, agent guard, embedder) show up as 0 ms points. This saves those
// other GUARDRAIL_* docs in the restore window (the last 8 days) to originals/target_metrics_data_removed.json,
// then deletes exactly those docs. Nothing else is touched. The rollback re-imports the file.
const fs = require('fs');
const windowStart = Math.floor(Date.now() / 1000) - 8 * 86400;
const filter = {
  metricId: { $regex: '^GUARDRAIL_', $nin: ['GUARDRAIL_REQUEST_LATENCY', 'GUARDRAIL_RESPONSE_LATENCY'] },
  timestamp: { $gte: windowStart },
  demoSeedArgus: { $exists: false },
};
fs.mkdirSync('originals', { recursive: true });
const out = 'originals/target_metrics_data_removed.json';
const lines = [];
const ids = [];
// promoteValues: false keeps BSON types (a double 16.0 stays a double), so the rollback restores docs exactly
db.metrics_data.find(filter, {}, { promoteValues: false }).forEach(d => { lines.push(EJSON.stringify(d, { relaxed: false })); ids.push(d._id); });
fs.writeFileSync(out, lines.join('\n') + (lines.length ? '\n' : ''));
let deleted = 0;
for (let i = 0; i < ids.length; i += 1000) {
  deleted += db.metrics_data.deleteMany({ _id: { $in: ids.slice(i, i + 1000) } }).deletedCount;
}
printjson({ windowStart: windowStart, savedTo: out, saved: lines.length, deleted: deleted });
