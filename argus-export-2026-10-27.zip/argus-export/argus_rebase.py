"""Shift every Argus timestamp so the demo looks as fresh on the target as it did when it was exported.

    python3 argus_rebase.py [--now EPOCH] [--offset SECONDS] [--src .] [--out rebased]

Reads mongo/*.json (canonical Extended JSON) and traces.ndjson from --src, and writes the same files to --out
with every epoch field moved by offset = now - manifest["data_time"]. A field is an epoch when its name says
so (…At, …Ts, …Timestamp, timestamp, …Time, time, lastSeen, lastTested, lastDetected, lastUpdated) and its value
is a date in seconds or milliseconds; ids, counts, ObjectIds and text are left alone. Only this package's files
are rewritten, so ATLAS data keeps its own timestamps. Standard library only.
"""
import argparse
import json
import os
import re
import sys
import time

FIELD = re.compile(r"(At|Ts|Timestamp|timestamp|Time|time|lastSeen|lastTested|lastDetected|lastUpdated)$")
SEC = (1_500_000_000, 2_200_000_000)
MS = (SEC[0] * 1000, SEC[1] * 1000)


def shift(v, off, counts):
    """v: a JSON value under an epoch-named key. Canonical EJSON numbers keep their type."""
    if isinstance(v, dict) and len(v) == 1 and next(iter(v)) in ("$numberInt", "$numberLong", "$numberDouble"):
        k = next(iter(v))
        n = float(v[k]) if k == "$numberDouble" else int(v[k])
        m = moved(n, off, counts)
        if m is None:
            return v
        if k == "$numberInt" and not (-2 ** 31 <= m < 2 ** 31):
            return {"$numberLong": str(int(m))}
        return {k: repr(float(m)) if k == "$numberDouble" else str(int(m))}
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        m = moved(v, off, counts)
        return v if m is None else (type(v))(m)
    return walk(v, off, counts)


def moved(n, off, counts):
    if SEC[0] <= n <= SEC[1]:
        counts["seconds"] += 1
        return n + off
    if MS[0] <= n <= MS[1]:
        counts["milliseconds"] += 1
        return n + off * 1000
    return None


def walk(o, off, counts):
    if isinstance(o, dict):
        if len(o) == 1 and next(iter(o)).startswith("$"):
            return o                                   # an EJSON scalar (ObjectId, date...) that isn't under an epoch key
        return {k: (shift(v, off, counts) if FIELD.search(k) else walk(v, off, counts)) for k, v in o.items()}
    if isinstance(o, list):
        return [walk(x, off, counts) for x in o]
    return o


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--src", default=".")
    p.add_argument("--out", default="rebased")
    p.add_argument("--now", type=int, default=int(time.time()), help="the time to rebase to (default: now)")
    p.add_argument("--offset", type=int, help="shift by this many seconds instead of now - data_time")
    a = p.parse_args()
    man = json.load(open(os.path.join(a.src, "manifest.json")))
    off = a.offset if a.offset is not None else a.now - int(man["data_time"])
    counts = {"seconds": 0, "milliseconds": 0}
    os.makedirs(os.path.join(a.out, "mongo"), exist_ok=True)
    docs = 0
    for fn in sorted(os.listdir(os.path.join(a.src, "mongo"))):
        if not fn.endswith(".json"):
            continue
        with open(os.path.join(a.src, "mongo", fn)) as f, open(os.path.join(a.out, "mongo", fn), "w") as g:
            for line in f:
                if line.strip():
                    g.write(json.dumps(walk(json.loads(line), off, counts), separators=(",", ":")) + "\n")
                    docs += 1
    traces = 0
    with open(os.path.join(a.src, "traces.ndjson")) as f, open(os.path.join(a.out, "traces.ndjson"), "w") as g:
        for line in f:
            if line.strip():
                row = json.loads(line)
                row["_source"] = walk(row["_source"], off, counts)
                g.write(json.dumps(row) + "\n")
                traces += 1
    out_man = dict(man, data_time=int(man["data_time"]) + off, rebased_by=off)
    with open(os.path.join(a.out, "manifest.json"), "w") as f:
        json.dump(out_man, f, indent=1)
    print(json.dumps({"offset_seconds": off, "offset_days": round(off / 86400.0, 2), "mongo_docs": docs, "trace_docs": traces,
                      "timestamps_shifted": counts, "new_data_time": out_man["data_time"]}))


if __name__ == "__main__":
    sys.exit(main())
