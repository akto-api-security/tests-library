# Adding the Argus demo to account 1788909013 (add-only)

This folder adds the Akto ARGUS demo (the homegrown AI of the fictional company "Northwind") to an
account that already has the ATLAS demo restored from `demo-export/1788909013.archive`.

Nothing here drops or replaces a collection. ATLAS data keeps its content and timestamps:

- **Argus docs:** every one carries `demoSeedArgus: "argus-demo-v1"`. They're imported with `mongoimport --mode=upsert`, keyed by `_id`.
- **Docs already on the target:** a few belong to legacy AGENTIC data that Argus took over:
  - 16 guardrail policies
  - 466 alerts
  - 273 `actor_info` rows

  The upsert replaces the target's copy of these. `argus_preimage.js` saves that copy first, so the rollback can put it back.
- **Two scoped changes to non-Argus records**, both saved for rollback:
  - **Required patch:** the `violations` field of 380 ATLAS endpoint records (step 6).
  - **Required clean-up:** the guardrail service's own `GUARDRAIL_*` gauges in the last 8 days of `metrics_data` (step 4).
- **Timestamps:** the Argus data is moved to the restore time (step 3), so "last 7 days" views look the same as when it was exported.

| File | What it is |
|---|---|
| `mongo/<collection>.json` | Argus docs, one per line, canonical Extended JSON, 23 collections |
| `common/guardrail_compliance_infos.json` | Compliance by Argus policy name (SOC 2, OWASP Agentic Top 10, OWASP LLM, NIST AI RMF) for Reports > Threat, imported into the `common` database |
| `traces.ndjson` | Argus traces only, in elasticdump format. None has `isAtlasTraffic`. |
| `patches/api_info_violations.json` | `{_id, violations}` for 380 ATLAS endpoint records |
| `originals/` | Main's archive version of every doc the import or patch replaces (for reference). At restore time, `target_metrics_data_removed.json` is added here (step 4). |
| `argus_rebase.py` | Shifts every Argus timestamp by (restore time − `data_time`) into `rebased/`. Python 3 standard library only. |
| `argus_metrics_cleanup.js` | Saves, then deletes, the other `GUARDRAIL_*` metric points in the restore window |
| `argus_preimage.js` | Saves the target's current copy of every doc this package replaces |
| `manifest.json` | Counts per collection, and `data_time`: the moment the Argus data describes (2026-10-24 05:37 UTC) |
| `SHA256SUMS` | Checksums. Run `shasum -a 256 -c SHA256SUMS` after copying. |

Everything is scrubbed with the same rules as the ATLAS export. There are no internal names, paths, hosts or
real people. **The target must use account id `1788909013`.**

Placeholders:

```bash
TARGET_MONGO='mongodb://<user>:<pass>@<host>:27017'      # the Mongo the dashboard and threat backend use
AUTH='authSource=admin'
ES='http://<es-host>:9200'
STAMP=$(date +%Y%m%d-%H%M)
cd argus-export
shasum -a 256 -c SHA256SUMS
```

## 1. Back up first

Stop the dashboard and the threat backend. Their crons write to this database.

```bash
mkdir -p backup-$STAMP
mongodump --uri "$TARGET_MONGO/?$AUTH" --db 1788909013 --gzip --archive=backup-$STAMP/1788909013.archive
elasticdump --input="$ES/agent_query_logs" --output=backup-$STAMP/traces.ndjson --type=data \
  --searchBody='{"query":{"term":{"accountId":1788909013}}}' --limit=1000
```

Check that the archive is non-empty.

**The dashboard must already have run on this account.** One-time migrations record a flag in
`1788909013.backward_compatibility`. On a database without those flags, the first dashboard start causes two problems:
- `readyForNewTestingFramework` deletes `testing_run` and `testing_run_result`, the AI red-teaming runs.
- `moveUserDataFromModuleInfoToAgenticUsers` adds about 500 user records, which ATLAS check Q8 counts as duplicates.

Check before you continue:

```bash
mongosh "$TARGET_MONGO/1788909013?$AUTH" --quiet --eval 'printjson(db.backward_compatibility.findOne({}, {readyForNewTestingFramework: 1, moveUserDataFromModuleInfoToAgenticUsers: 1}))'
```

Both should be non-zero timestamps. If they aren't, start the dashboard once and stop it, then continue.
If the threat backend uses a different Mongo, run steps 2–6 against it as well.

## 2. Save the target's copy of what will be replaced

```bash
mongosh "$TARGET_MONGO/1788909013?$AUTH" --quiet argus_preimage.js
```

This writes `preimage/`. Expected:
- 16 `guardrail_policies`
- 466 `malicious_events`
- 273 `actor_info`
- 380 `patch_api_info_violations`
- any `yaml_templates` the target already has
- any of the 8 `filter_yaml_templates` the target already has (main's archive has none)

Keep `preimage/` with the backup; the rollback needs it.

## 3. Rebase the Argus timestamps to now

```bash
python3 argus_rebase.py --out rebased        # prints the offset; e.g. {"offset_days": 3.0, ...}
```

Every epoch field in `mongo/*.json` and `traces.ndjson` moves by (now − `data_time`), in seconds or milliseconds as stored. That covers:
- events
- actor rows
- trace spans
- latency points
- session timelines
- red-teaming runs, results and issues
- discovery, last-seen and last-tested times
- posture history

The output goes to `rebased/`. Steps 5 and 7 import from there. Nothing in the database is touched and ATLAS keeps its timestamps.
Run this step on the day you restore. `--now <epoch>` rebases to a specific time instead.

## 4. Clear the other guardrail gauges from the latency chart's window

```bash
mongosh "$TARGET_MONGO/1788909013?$AUTH" --quiet argus_metrics_cleanup.js
```

**Why:** the Guardrail Detection Latency chart (`POST /api/metrics`, `metricIdPrefix: GUARDRAIL_`) draws a point for every
`GUARDRAIL_*` timestamp but reads only `GUARDRAIL_REQUEST_LATENCY` and `GUARDRAIL_RESPONSE_LATENCY`. The guardrail service's
other per-minute gauges (CPU, memory, goroutines, cache, agent guard, embedder) therefore plot as 0 ms.

**What it does:**
- Saves every such doc from the last 8 days to `originals/target_metrics_data_removed.json`, then deletes exactly those docs.
- Leaves `GUARDRAIL_REQUEST_LATENCY` / `GUARDRAIL_RESPONSE_LATENCY`, every other metric and older points alone.

**Side effect:** Settings → Module Metrics no longer shows those gauges for those 8 days.

If the target's guardrail service writes its own request/response latency points in this window, they stay. They'll interleave with the Argus series.

## 5. Import Mongo (upsert, no drop)

```bash
for f in rebased/mongo/*.json; do
  c=$(basename "$f" .json)
  mongoimport --uri "$TARGET_MONGO/?$AUTH" --db 1788909013 --collection "$c" --mode=upsert --file "$f"
done
```

Each line should end in `N document(s) imported successfully. 0 document(s) failed to import.` Totals:

| Collection | Docs | Already on the target (replaced) |
|---|---|---|
| actor_info | 349 | 273 |
| agent_conversation_results | 3,008 | 0 |
| agentic_posture_score_history | 374 | 0 |
| agentic_session_context | 405 | 0 |
| api_collection_stats | 256 | 0 |
| api_collections | 256 | 0 |
| api_info | 1,396 | 0 |
| custom_auth_type | 1 | 0 |
| filter_yaml_templates | 8 | 0 (only the Akto threat filters the target lacks are shipped) |
| guardrail_policies | 29 | 16 |
| historical_data | 2,717 | 0 |
| malicious_events | 2,116 | 466 |
| mcp_audit_info | 763 | 0 |
| metrics_data | 1,536 | 0 |
| single_type_info | 1,485 | 0 |
| test_roles | 9 | 0 |
| testing_run | 58 | 0 |
| testing_run_config | 58 | 0 |
| testing_run_issues | 164 | 0 |
| testing_run_result | 4,836 | 0 |
| testing_run_result_summaries | 206 | 0 |
| vulnerable_testing_run_results | 341 | 0 |
| yaml_templates | 514 | the target's own copies of the 94 library templates, if it has them |

Then the compliance docs for the `common` database. The Threat report looks up, by policy name, the guardrail rules that have no
built-in capability. Only Argus-only policy names are included; the three names ATLAS also uses keep ATLAS's mapping.

```bash
mongoimport --uri "$TARGET_MONGO/?$AUTH" --db common --collection guardrail_compliance_infos --mode=upsert \
  --file common/guardrail_compliance_infos.json
```

`test_roles` has a unique index on `name`. If the target already has a role with one of these names, the upsert fails for that role:
- the four scan roles: CLAIMS_ADJUSTER, POLICYHOLDER, READ_ONLY_ANALYST, PLATFORM_ADMIN
- the five User Config roles: ATTACKER_TOKEN_POLICYHOLDER, MEMBER, LOCKED_ACCOUNT_SYSTEM_ROLE, LOGGED_OUT_SYSTEM_ROLE, LOGIN_2FA_INCOMPLETE_SYSTEM_ROLE

Rename or remove the target's role first.

## 6. Required patch: ATLAS endpoint violation counts (380 records, one field)

The 466 legacy AGENTIC alerts sit on ATLAS device endpoints in main's archive, and those endpoints'
`api_info.violations` still count them. Argus moves these alerts onto its own agents, so this patch recomputes
`violations` on the 380 endpoint records to count only the ATLAS alerts still on them. No other field changes.
Without it, the endpoint grids overcount violations and ATLAS validation fails check "R-A endpoint violation counts = its alerts" (96/97).

```bash
mongoimport --uri "$TARGET_MONGO/?$AUTH" --db 1788909013 --collection api_info --mode=merge \
  --file patches/api_info_violations.json
```

## 7. Import the Argus traces (ATLAS traces stay)

There is no delete. Argus trace ids start with `argus-`.

```bash
elasticdump --input=rebased/traces.ndjson --output="$ES/agent_query_logs" --type=data --limit=1000
curl -s -X POST "$ES/agent_query_logs/_refresh" >/dev/null
curl -s "$ES/agent_query_logs/_count" -H 'Content-Type: application/json' \
  -d '{"query":{"term":{"demoSeed.keyword":"argus-demo-v1"}}}'          # expect "count":11988
```

## 8. Plan features for the org

Turn these on in the plan / Stigg admin for the org that owns account `1788909013`, then log out and back in.
Entitlements are cached for about 15 minutes.

| Feature flag | What it unlocks in Argus |
|---|---|
| `SECURITY_TYPE_AGENTIC` | the **Akto ARGUS** entry in the product switcher |
| `THREAT_DETECTION`, `THREAT_PROTECTION` | Guardrail activity, **Agentic Components under Guardrail**, and the dashboard's **Guardrail Requests over time** and posture-chart guardrail line. The page only requests that series when its plan map grants `THREAT_DETECTION`. |
| `SENSITIVE_DATA` | the Guardrail policies list and editor |
| `API_COLLECTIONS` | Agentic components, dashboard discovery and threat summary, posture |
| `TEST_RESULTS`, `ISSUES` | AI red-teaming runs, results and issues |
| (role access `TEST_ROLES`) | the scan roles and User Config pages |
| `AGENT_TRAFFIC_LOGS`, `LOGS`, `ADMIN_ACTIONS` | Traces and trace detail |

## 9. Restart and check

Start the dashboard and threat backend, switch to **Akto ARGUS**, and check:

| Where | Expect |
|---|---|
| Collections | 256 rows on the Hostname tab: 50 agents, 192 MCP connections, 14 LLM endpoints |
| Guardrail activity | 2,116 events. About 20% are "Session" detections, and their timeline is 3–6 steps about one person and record. |
| Guardrail Detection Latency (Last 7 days) | one smooth series: incoming 25–60 ms, output 40–90 ms, total about 70–150 ms |
| Dashboard (Last 2 months) | Guardrail Requests over time, and the guardrail line on the posture chart |
| AI Red Teaming | 58 runs and their issues. Test Roles lists the 4 scan roles (authored by Morgan Ellis, Sandra Reyes, Megan Wilson, Betty Cook). User Config has no Pending rows. |
| Reports > Threat (SOC 2 / OWASP Agentic Top 10 / OWASP LLM / NIST AI RMF, 7 days) | Argus guardrail events listed under each framework |
| Guardrails > Human approval | severity by the amount (about 40% critical, 40% high, 20% medium); no requester more than 3 times |
| Traces | about 2,500 sessions on the Argus agents |

**Before checking Reports > Threat and Guardrail activity, log out from the profile menu and log back in (or use a new
browser tab).** The dashboard caches the guardrail compliance map in the browser tab (`sessionStorage`, key
`Akto-session-store`) the first time a Threat or Guardrail page loads, and reuses it until an explicit logout. A tab opened
before the import keeps the old map, even after a hard reload or a re-login after a session timeout. Symptoms: SOC 2 and OWASP
Agentic Top 10 show "No threats found", and OWASP LLM shows only a few policies. No dashboard or backend restart is needed; the
server reads `guardrail_compliance_infos` and the policies from Mongo on every request.

Reports > Threat also needs the account's threat filter templates (`filter_yaml_templates`): with none, the page shows
"No guardrail violations yet!" and loads nothing. The dashboard only syncs them at startup for metered accounts with threat
policies, and main's archive has none, so `mongo/filter_yaml_templates.json` ships Akto's 8 (SSRF, SQL injection, XSS, ...),
tagged so the rollback removes them.

**Known limits on stock code**, in an account that also holds ATLAS data:
- the Agentic AI Discovery widget stays empty
- the Recent Changes new-params card shows 0
- the Collections header coverage counts the whole account
- the Home Risk Score and Test Coverage show their full value as the "in 1 year" delta
- components show "New" when they were last seen in the past 30 days

## 10. Roll back (removes only Argus, restores what it replaced)

```bash
# 1. remove every Argus-tagged doc
mongosh "$TARGET_MONGO/1788909013?$AUTH" --quiet --eval '
  db.getCollectionNames().forEach(c => {
    const r = db.getCollection(c).deleteMany({demoSeedArgus: {$exists: true}});
    if (r.deletedCount) print(c, r.deletedCount);
  })'

# 2. put back the target's own copies (adopted policies / alerts / actor rows, library templates, violations)
for f in preimage/*.json; do
  b=$(basename "$f" .json)
  [ -s "$f" ] || continue
  case "$b" in
    patch_*) mongoimport --uri "$TARGET_MONGO/?$AUTH" --db 1788909013 --collection api_info --mode=merge --file "$f" ;;
    common_*) ;;                                   # handled in 3.
    *)       mongoimport --uri "$TARGET_MONGO/?$AUTH" --db 1788909013 --collection "$b" --mode=upsert --file "$f" ;;
  esac
done

# 3. common: remove Argus docs, put back the target's own copies of the same ids
mongosh "$TARGET_MONGO/common?$AUTH" --quiet --eval 'db.guardrail_compliance_infos.deleteMany({demoSeedArgus: {$exists: true}})'
for f in preimage/common_*.json; do [ -s "$f" ] && mongoimport --uri "$TARGET_MONGO/?$AUTH" --db common \
  --collection "$(basename "$f" .json | sed 's/^common_//')" --mode=upsert --file "$f"; done

# 4. put back the guardrail gauges taken out in step 4
[ -s originals/target_metrics_data_removed.json ] && mongoimport --uri "$TARGET_MONGO/?$AUTH" --db 1788909013 \
  --collection metrics_data --mode=upsert --file originals/target_metrics_data_removed.json

# 5. Argus traces only (ATLAS traces stay)
curl -s -X POST "$ES/agent_query_logs/_delete_by_query?conflicts=proceed&refresh=true" \
  -H 'Content-Type: application/json' -d '{"query":{"term":{"demoSeed.keyword":"argus-demo-v1"}}}'
```

If anything looks off, restore the full backup from step 1 instead:
`mongorestore --uri "$TARGET_MONGO/?$AUTH" --gzip --archive=backup-$STAMP/1788909013.archive --nsInclude='1788909013.*' --drop`.
Then turn off any feature flags from step 8 that weren't on before.
