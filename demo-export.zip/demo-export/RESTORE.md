# Restoring the agentic demo (account 1788909013)

This folder holds the seeded Akto ATLAS demo for account `1788909013`. It was dumped from the local
demo setup on 2026-10-22 so it can be restored on the main deployment.

| File | What it is |
|---|---|
| `1788909013.archive` | `mongodump --gzip --archive` of database `1788909013`. It holds only the 25 collections the demo needs (list below). |
| `traces.ndjson` | elasticdump export of index `agent_query_logs`. It holds only `accountId: 1788909013`, 31,142 docs. |
| `mcp-registry-approved.csv` | The 93 approved MCP servers for the MCP registry (column `mcp_server_name`) |
| `SHA256SUMS` | Checksums. Run `shasum -a 256 -c SHA256SUMS` after copying. |

Nothing from `common`, `billing` or `admin` is included. Restoring those would overwrite other orgs.
The guardrail alerts (`malicious_events`) are in the account DB itself, so there is no separate threat archive.

**Before you start, check that the target uses account id `1788909013`.** The id appears inside
documents (`accountId` fields, trace docs). If the demo org on the target has a different account id,
stop. This package can't be renamed into another account.

Placeholders used below:

```bash
TARGET_MONGO='mongodb://<user>:<pass>@<host>:27017/?authSource=admin'   # the Mongo the dashboard uses
ES='http://<es-host>:9200'                                              # the ES the dashboard reads traces from
STAMP=$(date +%Y%m%d-%H%M)
```

## 1. Back up the target first

Stop the dashboard and the threat backend first. Their crons write to this database.

```bash
mkdir -p backup-$STAMP
mongodump --uri "$TARGET_MONGO" --db 1788909013 --gzip --archive=backup-$STAMP/1788909013.archive

# existing traces for this account (the file may be empty if there are none)
elasticdump --input="$ES/agent_query_logs" --output=backup-$STAMP/traces.ndjson --type=data \
  --searchBody='{"query":{"term":{"accountId":1788909013}}}' --limit=1000
```

Check that `backup-$STAMP/1788909013.archive` is non-empty before you continue.

If the threat backend uses a **different Mongo** from the dashboard, back up `malicious_events` there
as well. Check its Mongo URI env var on the target. The command is the same, using that URI.

## 2. Restore Mongo

```bash
mongorestore --uri "$TARGET_MONGO" --gzip --archive=1788909013.archive \
  --nsInclude='1788909013.*' --drop
```

- `--nsInclude` limits the restore to database `1788909013`.
- `--drop` only drops the 25 collections that are in the archive.
- Every other collection in `1788909013` stays as it is: testing runs, account settings, logs, custom roles and so on.
- No other database is touched.

Expected end of output: `... document(s) restored successfully. 0 document(s) failed to restore.`

If the threat backend has its own Mongo, also run:

```bash
mongorestore --uri "$THREAT_MONGO" --gzip --archive=1788909013.archive \
  --nsInclude='1788909013.malicious_events' --drop
```

## 3. Load the traces

Remove this account's old traces first so old and new sessions don't mix. Then import.

```bash
curl -s -X POST "$ES/agent_query_logs/_delete_by_query?conflicts=proceed" \
  -H 'Content-Type: application/json' -d '{"query":{"term":{"accountId":1788909013}}}'

elasticdump --input=traces.ndjson --output="$ES/agent_query_logs" --type=data --limit=1000

curl -s -X POST "$ES/agent_query_logs/_refresh" >/dev/null
curl -s "$ES/agent_query_logs/_count" -H 'Content-Type: application/json' \
  -d '{"query":{"term":{"accountId":1788909013}}}'          # expect "count":31142
```

The source was Elasticsearch 7.17. The docs carry `_type: _doc`.

## 4. Turn on the plan features for the org

The local seed granted every feature in the local `billing` DB. That DB is **not** in this package,
so turn these on manually for the org that owns account `1788909013` in the plan / Stigg admin. Then
log out and back in. Entitlements are cached for about 15 minutes.

| Feature flag | What it unlocks |
|---|---|
| `AGENT_TRAFFIC_LOGS` | **Traces** menu (and `fetchLLMTraceDetail`) |
| `NHI_GOVERNANCE` | **NHI Governance** menu and NHI APIs |
| `NHI_DATA` | NHI identities, policies, violations APIs |
| `THREAT_DETECTION` | **Threat Detection** menu, guardrail alerts (`fetchSuspectSampleData`, reports) |
| `THREAT_PROTECTION` | the same alert APIs, plus status updates on alerts |
| `THREAT_SETTINGS` | threat configuration |
| `AI_AGENTS` | agentic menu, user analysis |
| `MCP_SECURITY` | MCP security pages |
| `SENSITIVE_DATA` | Guardrail policies list and editor |
| `API_COLLECTIONS` | Agentic assets, MCP audit, posture APIs |
| `ADMIN_ACTIONS` | agentic users, endpoint shield settings |
| `LOGS` | endpoint shield diagnostics |
| `INTEGRATIONS` | guardrail config, MCP registry settings |

The first three rows (Traces, NHI, Threat Detection) are the ones that hide whole menus. The rest are
enforced per API: a page opens but stays empty if its flag is missing.

## 5. Sync the MCP registry

1. Upload `mcp-registry-approved.csv` somewhere the dashboard can fetch it (a raw gist or bucket URL).
2. Go to Settings → Integrations → MCP Registry.
3. Set the URL to that file and click **Sync now**.

Use a URL that serves the latest version of the file. A gist link pinned to a revision keeps serving
the old content even after you edit the gist. `kubernetes-mcp` is left out on purpose.

## 6. Restart and check

Start the dashboard and the threat backend again. Log in to the demo org and check:

| Where | Expect |
|---|---|
| Agentic assets grid | **2,025** assets: 1,761 skills, 100 SaaS agents, 80 MCP servers, 47 plugins, 30 AI agents, 7 LLMs |
| Posture → Total Agentic Assets card | **1,000** (stock code counts endpoints/devices on this card) |
| Agentic assets → Gemini CLI → Components | 105 skills, 16 MCP servers, built-in tools (`run_shell_command`, `web_fetch`, ...) |
| Gemini CLI → Components → `mcp.zendesk.com` | a list of tools (`search_tickets`, ...) each with risk and violations |
| `mcp.testkg.com` | risk 5.0; Components shows all its tools flagged malicious; blocked violations by `block-malicious-mcp-servers`; last seen = time of its latest alert |
| Guardrails / Threat alerts | 3,248 alerts, dated 2026-09-14 → 2026-10-22 |
| Traces | sessions across the last ~30 days (31,142 docs) |
| NHI Governance | identities, policies and violations listed |

Device names, personas, alerts and traces all use the same fictional US personas.

## 7. Roll back

Restore what you saved in step 1. It's scoped the same way, so nothing else is touched.

```bash
mongorestore --uri "$TARGET_MONGO" --gzip --archive=backup-$STAMP/1788909013.archive \
  --nsInclude='1788909013.*' --drop

curl -s -X POST "$ES/agent_query_logs/_delete_by_query?conflicts=proceed" \
  -H 'Content-Type: application/json' -d '{"query":{"term":{"accountId":1788909013}}}'
elasticdump --input=backup-$STAMP/traces.ndjson --output="$ES/agent_query_logs" --type=data --limit=1000
```

Then turn the feature flags from step 4 back off if they weren't on before, and restore the previous
registry URL.

There is no seed-level rollback on the target. The seed's rollback store (`demo_seed_originals`)
holds unscrubbed original data and is deliberately **not** in this package. Rolling back means
restoring the backup.

## Timestamps are frozen at dump time

The newest alert is 2026-10-22 04:53 UTC, and the traces end the same day. From then on, everything
ages in real time:

- Alerts drop out of "last 7 / 30 days" views.
- Device heartbeats go stale, so devices start showing "No traffic in 30 days".
- Traces fall outside the 30-day window after about a month.

To refresh it, re-run the seed on the local setup (`demo-seed/`), which moves everything to the
current window, then dump again with the same commands.

## What is and isn't in the archive

**Included (25 collections):** `actor_info agent_users api_collection_stats api_collection_stats_meta
api_collections api_info config_field_policies endpoint_logical_group endpoint_mcp_config
endpoint_remote_command_executions endpoint_remote_commands file_inspection_results guardrail_policies
malicious_events mcp_allowlist mcp_audit_info module_info nhi_identities nhi_policies nhi_violations
sample_data sensitive_sample_data single_type_info traffic_info user_analysis_data`

**Left out, and why:**

- `demo_seed_originals`: unscrubbed originals, used only by the local rollback.
- `logs*`, `api_audit_logs`, `activities`, `protection_logs`, metrics and caches: runtime noise. The
  target writes its own.
- `accounts_settings`, `rbac`, `custom_roles`, `mcp_registry_config`, `copilot_studio_integration`,
  integration settings: the target keeps its own config. The seed only renamed text in these.
- Testing runs, YAML templates, data types, code analysis: not part of the demo.

**Scrubbing:**

- Internal names, repos and hosts have been rewritten.
- Real people, customer domains, cloud account ids and the original IPs were replaced with fictional ones.
- The built-in `Akto-*Guard` policy names are kept.
- In stored payloads, a few product field names were renamed: the VXLAN id field is now
  `shield_vxlan_id` and the installer headers are now `x-installer-*`. Only sample payload text has
  them, and nothing parses that.

## Known limits on stock code

- MCP server rows have no **Malicious** badge. Skills do.
- Risk Analysis has no "Malicious MCP server" factor.
- The Devices tab shows "-" for risk and last seen.
- Plugin rows show no risk.
- Skill rows show their install's risk.

Product fixes for the first two are on branch `fenil/agentic-malicious-mcp-asset-count`. That branch
also adds the posture card asset count.
